import React, { useCallback, useEffect, useRef } from 'react';

export default (props: { show: boolean; onClose: (show: false) => void }) => {
  const ref = useRef<HTMLDivElement>(null);
  // 判断一个是否是另一个的父
  const isParent = (obj: any, parentObj: HTMLElement | null) => {
    while (obj != undefined && obj != null && obj.tagName.toUpperCase() != 'BODY') {
      if (obj == parentObj) {
        return true;
      }
      obj = obj.parentNode;
    }
    return false;
  };

  // 监听器不重复创建，否则remove失败导致重复监听
  const listener = useCallback((ev: MouseEvent) => {
    // 和第二种方案唯一不同的就是，本方案是通过target而不是通过矩形位置
    if (isParent(ev.target, ref.current)) {
      console.log(Date.now(), '点击的是盒子内部');
    } else {
      console.log(Date.now(), '点击的是盒子外部,监听器已销毁');
      props.onClose(false);
    }
  }, []);
  // 生命周期钩子
  useEffect(() => {
    if (props.show) {
      window.addEventListener('mousedown', listener);
    }
    return () => {
      window.removeEventListener('mousedown', listener);
    };
  }, [props.show]);
  // renderer
  return (
    <>
      {props.show && (
        <div ref={ref} className='model-box'>
          <div>Model-box3</div>
          <button>inner button</button>
          <input />
        </div>
      )}
    </>
  );
};
