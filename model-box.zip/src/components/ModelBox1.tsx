import { useEffect, useRef } from 'react';

export default (props: { show: boolean; onClose: (show: false) => void }) => {
  const ref = useRef<HTMLDivElement>(null);
  // 焦点消失，触发销毁动作
  const onBlur = () => {
    props.onClose(false);
  };
  // 组件创建完毕时候，要具有焦点
  useEffect(() => {
    props.show && ref.current?.focus();
  });
  return (
    <>
      {props.show && (
        // 需要禁用mousedown，因为内部的子元素会夺走父元素的焦点，
        // 导致里面的button等不能点击，否则会触发close
        // 但是禁用mousedown，虽然按钮可以触发click，但是input不能输入，所以不推荐该方法
        <div ref={ref} onMouseDown={noop} onBlur={onBlur} tabIndex={1} className='model-box'>
          <div>Model-box1</div>
          <button>inner button</button>
          <input />
        </div>
      )}
    </>
  );
};

function noop(e: any) {
  e.preventDefault();
  return false;
}
