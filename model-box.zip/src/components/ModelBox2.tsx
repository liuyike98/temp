import React, { useCallback, useEffect, useRef } from 'react';

export default (props: { show: boolean; onClose: (show: false) => void }) => {
  const ref = useRef<HTMLDivElement>(null);
  const listener = useCallback((ev: MouseEvent) => {
    // 打开model后计算矩形位置
    const rect = ref.current?.getBoundingClientRect();
    if (
      rect &&
      /**鼠标在左右边界*/
      ev.clientX > rect.x &&
      ev.clientX < rect.right &&
      /**鼠标在上下边界内 */
      ev.clientY > rect.y &&
      ev.clientY < rect.bottom
    ) {
      console.log(Date.now(), '点击的是盒子内部');
    } else {
      console.log(Date.now(), '点击的是盒子外部,监听器已销毁');
      props.onClose(false);
    }
  }, []);
  useEffect(() => {
    if (props.show) {
      window.addEventListener('mousedown', listener);
    }
    return () => {
      window.removeEventListener('mousedown', listener);
    };
  }, [props.show]);

  return (
    <>
      {props.show && (
        <div ref={ref} className='model-box'>
          <div>Model-box2</div>
          <button>inner button</button>
          <input />
        </div>
      )}
    </>
  );
};
