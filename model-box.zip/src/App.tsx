import { useEffect, useMemo, useRef, useState } from 'react';
import './App.scss';
import ModelBox1 from './components/ModelBox1';
import ModelBox2 from './components/ModelBox2';
import ModelBox3 from './components/ModelBox3';


// 大概思路就是这样，推荐矩形位置判断的方法，开销比较小，也不会随层级增加而开销变大
// 而通过事件委托，用点击对象是否是父子元素，需要一直向上判断，直到body，层次越深，效率越低，不过对于点击效果来说可以忽略不记
function App() {
  // states
  const [show1, setShow1] = useState(false);
  const [show2, setShow2] = useState(false);
  const [show3, setShow3] = useState(false);
  // renderer
  return (
    <div className='main-content'>
      {/* model-boxes */}
      <ModelBox1 show={show1} onClose={setShow1} />
      <ModelBox2 show={show2} onClose={setShow2} />
      <ModelBox3 show={show3} onClose={setShow3} />
      {/* buttons */}
      <button onClick={() => setShow1(true)}>ModelBox1</button>
      <button onClick={() => setShow2(true)}>ModelBox2</button>
      <button onClick={() => setShow3(true)}>ModelBox3</button>
    </div>
  );
}

export default App;
