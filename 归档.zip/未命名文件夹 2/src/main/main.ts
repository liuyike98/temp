import { app } from 'electron';
import Application from '../../release/app/Runtime/Libs/Application';
import path from 'path';
import { URL } from 'url';
// 初始化 app
Application.init(app);
// 不同运行环境 path 不同
export function resolveHtmlPath(htmlFileName: string) {
  if (process.env.NODE_ENV === 'development') {
    const port = process.env.PORT || 1212;
    const url = new URL(`http://localhost:${port}`);
    url.pathname = htmlFileName;
    return url.href;
  }
  return `file://${path.resolve(__dirname, '../renderer/', htmlFileName)}`;
}
