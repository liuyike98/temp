import { BrowserWindow } from 'electron';
import fs from 'fs';
import path from 'path';

/**
 * 插件对象,用于管理插件加载状态
 */
class AppPlugin {
  isRunning: boolean = false;
  path?: string;
}

/**
 * 插件加载器
 */
export class PluginLoader {
  // 缓存加载的插件
  private plugins: AppPlugin[] = [];
  // 根据路径加载 plugin
  public constructor(pathArr?: string[]) {
    if (!pathArr) {
      return;
    }
    // load 对应的插件,生成 AppPlugin 状态对象
    for (const pluginPath of pathArr) {
      const plugin = this.activePlugin(pluginPath);
      if (!plugin) {
        continue;
      }
      this.plugins.push(plugin);
    }
  }
  /**
   * 激活指定路径的插件
   */
  private activePlugin(pluginPath: string): AppPlugin | void {
    const info = this.readPluginInfo(pluginPath);
    const win = new BrowserWindow({
      webPreferences: {
        webSecurity: false,
      },
    });
    const entry = path.join(pluginPath, info.entry.renderer);
    console.log(entry);

    win.loadFile(entry);
  }
  /**
   * 列出已加载的插件
   */
  public list() {
    return JSON.parse(JSON.stringify(this.plugins));
  }
  /**
   * 读取插件信息
   */
  private readPluginInfo(pluginPath: string) {
    const configJson = fs.readFileSync(path.join(pluginPath, 'config.json'), {
      encoding: 'utf-8',
    });
    try {
      return JSON.parse(configJson);
    } catch (err) {
      return null;
    }
  }
}

export default PluginLoader;
