import PluginLoader from './PluginLoader';

/**
 * 全局唯一的应用管理类
 */
export class Application {
  private static pluginLoader: PluginLoader;
  /**
   * 私有构造,不允许 new 对象
   */
  private constructor() {}
  /**
   * 初始化 app
   */
  static init(app: Electron.App) {
    app.whenReady().then(() => {
      const testPlugin = "/Users/liu/Desktop/test-plugin/release";
      this.pluginLoader = new PluginLoader([testPlugin]);
    });
  }
  
}

export default Application;
