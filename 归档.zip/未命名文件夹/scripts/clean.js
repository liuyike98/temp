const fs = require('fs');
const path = require('path');
// 清除 main dist
fs.rmSync(path.join(__dirname, '../release/main/'), {
  force: true,
  recursive: true,
});

const releasePath = path.join(__dirname, '../release');
const files = fs.readdirSync(releasePath, {
  encoding: 'utf-8',
  withFileTypes: true,
});
files.forEach((dirent) => {
  fs.rmSync(path.join(releasePath, dirent.name), {
    force: true,
    recursive: true,
  });
});
