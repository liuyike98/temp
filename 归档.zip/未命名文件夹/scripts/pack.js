const fs = require('fs');
const path = require('path');
const config = require('../project/config.json');
const root = path.join(__dirname, '../');

// ... 验证

// ...
fs.copyFileSync(
  path.join(root, 'project/config.json'),
  path.join(root, 'release/config.json')
);
