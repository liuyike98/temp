"use strict";
console.log('hello');
