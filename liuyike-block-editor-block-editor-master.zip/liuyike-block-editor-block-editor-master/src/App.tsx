import React from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.less';
import Workspace from './pages/workspace';
import "@arco-design/web-react/dist/css/arco.css";

export default class App extends React.Component {
  render(): React.ReactNode {
    return (
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Workspace />} />
          <Route path='/workspace' element={<Workspace />} />
        </Routes>
      </BrowserRouter>
    );
  }
}
