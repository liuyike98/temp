import { Node } from '@tiptap/react';
import { EditorView } from 'prosemirror-view';
import { DOMOutputSpec, NodeSpec, Node as ProseMirrorNode, NodeType } from 'prosemirror-model';
import StringUtils from './StringUtils';
export default {
  // 保障uuid的唯一性
  ensureUUID(node: ProseMirrorNode) {
    const { uuid } = node.attrs;
    if (uuid === undefined || uuid === null || uuid === '' || uuid.length !== 36 || document.querySelector(`[data-block-id="${uuid}"]`)) {
      node.attrs.uuid = StringUtils.uuidv4();
    }
    return node;
  },
  // 在文章末尾插入新的节点
  appendNode(view: EditorView, node: ProseMirrorNode) {
    
  },
};
