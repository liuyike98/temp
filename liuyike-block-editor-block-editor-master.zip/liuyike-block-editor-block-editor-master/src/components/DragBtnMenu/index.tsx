import { Divider, Dropdown, Menu } from '@arco-design/web-react';
import { IconArrowDown, IconArrowUp, IconBgColors, IconCopy, IconDelete, IconLink, IconSync } from '@arco-design/web-react/icon';
import ReactDOM from 'react-dom';
import './index.less';
import $ from 'jquery';

export default function showDragMenu(bindElement: any) {
  const id = 'model-mask';
  const rect = bindElement.getBoundingClientRect();
  $(`#${id}`).remove();
  const $mask = $('<div>').attr('id', id).appendTo('body');
  const dropList = (
    <Menu
      style={{ left: rect.left - 265, top: rect.top + rect.height / 2 }}
      onClickMenuItem={(key, event) => {
        hideMenu();
        console.log(key);
      }}
      className='drag-btn-menu'
      mode='pop'
      selectable={false}>
      <Menu.Item key='1'>
        <IconDelete />
        删除块
        <span className='cmd-key'>Del</span>
      </Menu.Item>
      <Menu.Item key='2'>
        <IconCopy />
        向下复制块
        <span className='cmd-key'>Ctrl + D</span>
      </Menu.Item>
      <Menu.Item key='3'>
        <IconSync />
        转换为
      </Menu.Item>
      <Menu.SubMenu
        key='4'
        title={
          <>
            <IconBgColors />
            设置颜色
          </>
        }>
        <Menu.Item key='4_0'>Wuhan</Menu.Item>
        <Menu.Item key='4_1'>Chengdu</Menu.Item>
      </Menu.SubMenu>
      <Menu.Item key='5'>
        <IconLink />
        复制块链接
        <span className='cmd-key'>Ctrl + Shift + C</span>
      </Menu.Item>
      <Divider style={{ margin: '4px 0' }} />
      <Menu.Item key='6'>
        <IconArrowUp />
        向上移动块
        <span className='cmd-key'>Alt + Shift + ↑</span>
      </Menu.Item>
      <Menu.Item key='7'>
        <IconArrowDown />
        向下移动块
        <span className='cmd-key'>Alt + Shift + ↓</span>
      </Menu.Item>
    </Menu>
  );
  ReactDOM.render(dropList, $mask[0]);
  $mask.on('click', (e) => {
    if (e.target.id === id) {
      hideMenu();
    }
  });
  const hideMenu = () => {
    $mask.addClass('exit');
    setTimeout(() => {
      ReactDOM.unmountComponentAtNode($mask[0]);
      $mask.remove();
    }, 220);
  };
}
