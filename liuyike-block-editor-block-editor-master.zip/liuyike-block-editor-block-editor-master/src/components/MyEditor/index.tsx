import { Editor, EditorContent, BubbleMenu, isTextSelection, Extension, useEditor } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import React, { CSSProperties, ReactNode, useEffect } from 'react';
import SchemaExts from './schema';
import FakeData from './data/FakeData';
import MyExtensions from './extension';
import './index.less';
import BlockTitle from './schema/nodes/BlockTitle';
import { Plugin } from 'prosemirror-state';
import { MyToolTip } from './components/MyToolTip';
import MyMenuTip from './components/MyMenuTip';

export default () => {
  const editor = useEditor({
    extensions: [...SchemaExts, ...MyExtensions],
    content: FakeData,
  });
  (window as any).editor = editor;

  return (
    <>
      {editor && (
        <>
          <MyToolTip editor={editor} />
        </>
      )}
      <EditorContent
        className='my-editor'
        onDragStart={(e) => {
          e.preventDefault();
        }}
        spellCheck={false}
        // {...this.props}
        editor={editor}
      />
    </>
  );
};
