import { Node } from '@tiptap/react';
import BlockText from './BlockText';
import BlockTitle from './BlockTitle';

export const Doc = Node.create({
  name: 'doc',
  topNode: true,
  content: `${BlockTitle.name} block*`,
});

export default Doc;
