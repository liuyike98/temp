import { getSchema, Mark, Node } from '@tiptap/react';
import Doc from './nodes/Doc';
import BlockText from './nodes/BlockText';
import Text from './nodes/Text';
import BlockTitle from './nodes/BlockTitle';
import { Bold } from './marks/Bold';
import { Strike } from './marks/Strike';
import { Italic } from './marks/Italic';
import { Color } from './marks/Color';
import { OrderedList } from './nodes/OrderedList';
import { ListItem } from './nodes/ListItem';
import { BulletList } from './nodes/BulletList';
import { ShortCode } from './marks/ShortCode';
import { Underline } from './marks/UnderLine';
import { Heading } from './nodes/Heading';

// 分开定义,一个schema一个文件
export const nodes: Node[] = [Doc, BlockTitle, BlockText, Heading, BulletList, OrderedList, ListItem, Text];
export const marks: Mark[] = [ShortCode, Bold, Underline, Strike, Italic, Color];
// 合并nodes和marks的schema
export const SchemaExts = [...nodes, ...marks];
export const MySchema = getSchema(SchemaExts);
// 导出合并
export default SchemaExts;
