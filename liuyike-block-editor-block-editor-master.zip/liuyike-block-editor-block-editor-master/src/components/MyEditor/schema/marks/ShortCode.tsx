import { Extension } from '@tiptap/core';
import { Mark, mergeAttributes } from '@tiptap/react';

declare module '@tiptap/core' {
  interface Commands<ReturnType> {
    shortCode: {
      setShortCode: () => ReturnType;
      unsetShortCode: () => ReturnType;
      toggleShortCode: () => ReturnType;
    };
  }
}

export const ShortCode: Mark = Mark.create({
  name: 'ShortCode',
  parseHTML() {
    return [
      {
        tag: 'span',
      },
    ];
  },

  renderHTML({ HTMLAttributes }) {
    return ['span', mergeAttributes(this.options.HTMLAttributes, HTMLAttributes), 0];
  },

  addOptions() {
    return {
      HTMLAttributes: { class: 'mark-short-code' },
    };
  },

  addCommands() {
    return {
      setShortCode:
        () =>
        ({ commands }) => {
          return commands.setMark(this.name);
        },
      unsetShortCode:
        () =>
        ({ commands }) => {
          return commands.unsetMark(this.name);
        },
      toggleShortCode:
        () =>
        ({ commands }) => {
          return commands.toggleMark(this.name);
        },
    };
  },
  addKeyboardShortcuts() {
    return {
      'Mod-e': () => this.editor.commands.toggleShortCode(),
      'Mod-E': () => this.editor.commands.toggleShortCode(),
    };
  },
});
