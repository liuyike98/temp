export default {
  "type": "doc",
  "attrs": {
   "uuid": "80bdc809-8483-4f9c-840c-440ce9c1f185"
  },
  "content": [
   {
    "type": "BlockTitle",
    "attrs": {
     "uuid": "680e70f1-873f-4e6f-a71a-623ed05699eb"
    },
    "content": [
     {
      "type": "text",
      "text": "未命名文档😙"
     }
    ]
   },
   {
    "type": "BlockText",
    "attrs": {
     "uuid": "ac73aab2-f506-4a02-85df-161adc22a01f"
    },
    "content": [
     {
      "type": "text",
      "text": "hello world,你好世界"
     }
    ]
   },
   {
    "type": "bulletList",
    "content": [
     {
      "type": "ListItem",
      "content": [
       {
        "type": "BlockText",
        "attrs": {
         "uuid": "faefe68b-ec09-46f3-ab6d-569cfbc419e8"
        },
        "content": [
         {
          "type": "text",
          "text": "dfdsjkfldskjfds"
         }
        ]
       },
       {
        "type": "bulletList",
        "content": [
         {
          "type": "ListItem",
          "content": [
           {
            "type": "BlockText",
            "attrs": {
             "uuid": "e985841b-d0cf-410b-bb64-11d653ccfb3d"
            },
            "content": [
             {
              "type": "text",
              "text": "sdfdsfsdfsdfds"
             }
            ]
           },
           {
            "type": "bulletList",
            "content": [
             {
              "type": "ListItem",
              "content": [
               {
                "type": "BlockText",
                "attrs": {
                 "uuid": "dfa35f69-5dc4-45c1-b699-3af160c10742"
                },
                "content": [
                 {
                  "type": "text",
                  "text": "撒旦发射点发射点"
                 }
                ]
               }
              ]
             }
            ]
           }
          ]
         }
        ]
       }
      ]
     }
    ]
   }
  ]
 }