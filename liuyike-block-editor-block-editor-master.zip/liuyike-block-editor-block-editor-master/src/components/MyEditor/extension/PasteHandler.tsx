import BlockText from '../schema/nodes/BlockText';
import { Extension } from '@tiptap/core';
import { Plugin, PluginKey, TextSelection } from 'prosemirror-state';
import { Node as ProsemirrorNode, Slice, Fragment } from 'prosemirror-model';

// 该扩展的作用为:处理粘贴事件
export const PasteHandler = Extension.create({
  name: 'ext-paste-handler',
  addProseMirrorPlugins() {
    return [
      new Plugin({
        key: new PluginKey('ext-paste-handler'),
        props: {
          handleDOMEvents: {
            mousedown(view, ev) {
              if (ev.button === 0) {
                const { tr, selection } = view.state;
                if (selection.content().size > 0) {
                  tr.setSelection(new TextSelection(view.state.doc.resolve(0)));
                  view.dispatch(tr);
                }
              }
              return false;
            },
          },

          handlePaste: (view, event, slice) => {
            // 判断剪贴板类型
            // 剪贴板没有数据就不处理了
            if (!event.clipboardData) {
              return false;
            }

            // 获取文本数据
            const text = event.clipboardData.getData('text/plain');
            // 处理vscode相关的文本
            const vscode = event.clipboardData.getData('vscode-editor-data');
            const vscodeData = vscode ? JSON.parse(vscode) : undefined;
            const { tr, schema } = view.state;
            if (vscodeData) {
              const language = vscodeData.mode;
              // 粘贴转换操作
              const lines = text.replaceAll('\r\n', '\n').split('\n');
              const newNodes: ProsemirrorNode[] = [];
              lines.forEach((line, index) => {
                line = line.trim();
                console.log(line);
                newNodes.push(schema.nodes[BlockText.name].create({}, line ? schema.text(line) : []));
              });
              tr.replaceSelection(new Slice(Fragment.from(newNodes), 0, 0));
            } else {
              tr.replaceSelection(slice);
            }
            view.dispatch(tr);
            return true;
          },
        },
      }),
    ];
  },
});


