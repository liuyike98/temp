import { Editor, Extension } from '@tiptap/core';
import { Node as ProsemirrorNode } from 'prosemirror-model';
import { Decoration, DecorationSet } from 'prosemirror-view';
import { Plugin, PluginKey } from 'prosemirror-state';
import './index.less';
import $, { extend } from 'jquery';
import React from 'react';
import showDragMenu from '../../../DragBtnMenu';

const extName = 'DragPlugin';
let leftBox: HTMLDivElement | null = null;
let editor: Editor | null = null;
export const DragPlugin = Extension.create({
  name: extName,
  // 插件创建时,添加div
  onCreate(this) {
    editor = this.editor;
    if (leftBox) {
      editor.view.dom.parentElement?.removeChild(leftBox);
    }
    leftBox = document.createElement('div');
    leftBox.className = extName;
    leftBox.addEventListener('click', () => {
      showDragMenu(leftBox);
    });
    editor.view.dom.parentElement?.appendChild(leftBox);
    // 添加鼠标移动事件
    editor.view.dom.removeEventListener('mousemove', mousemove as any);
    editor.view.dom.addEventListener('mousemove', mousemove as any);
    hideDragger();
  },
  // 插件销毁时,移除div
  onDestroy() {
    if (leftBox) {
      document.body.removeChild(leftBox);
    }
  },
  // 更新时,隐藏div
  onUpdate() {},
  addProseMirrorPlugins() {
    return [
      new Plugin({
        props: {
          handleTextInput(view, from, to, text) {
            hideDragger();
            return false;
          },
        },
      }),
    ];
  },
});

function mousemove(this: any, e: MouseEvent) {
  // 鼠标当前位置
  const { clientX, clientY } = e;
  // 找到所有可移动的块
  const $blocks = $(this.editor.view.dom).find('div[block-type]');
  // 判断哪个块在命中范围
  for (const block of $blocks) {
    const { top, bottom, left, right } = block.getBoundingClientRect();
    if (clientX > right) {
      hideDragger();
      break;
    }
    if (clientY >= top && clientY <= bottom) {
      showDragger(block);
      break;
    }
  }
}

function showDragger(block: HTMLElement) {
  if (!leftBox) {
    return;
  }
  const blockRect = block.getBoundingClientRect();
  const editorRect = editor?.view.dom.parentElement?.getBoundingClientRect() || { left: 0, top: 0, right: 0, bottom: 0 };
  $(leftBox)
    .css({
      left: blockRect.left - editorRect.left - 30,
      top: blockRect.top - editorRect.top + 6,
    })
    .show();
}

function hideDragger() {
  if (!leftBox) {
    return;
  }
  $(leftBox).hide();
}
