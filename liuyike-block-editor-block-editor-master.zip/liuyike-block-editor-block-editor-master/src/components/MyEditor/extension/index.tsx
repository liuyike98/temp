import { History } from '@tiptap/extension-history';
import { BlockUUID } from './BlockUUID';
import { DragPlugin } from './DragPlugin';
import { PasteHandler } from './PasteHandler';
import { Placeholder } from './Placeholder';

export const MyExtensions = [History, BlockUUID, PasteHandler, Placeholder, DragPlugin];

export default MyExtensions;
