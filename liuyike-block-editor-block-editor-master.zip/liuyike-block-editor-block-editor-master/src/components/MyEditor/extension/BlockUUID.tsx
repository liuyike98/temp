import { Node } from '@tiptap/react';
import BlockText from '../schema/nodes/BlockText';
import Doc from '../schema/nodes/Doc';
import { Extension } from '@tiptap/core';
import { Plugin } from 'prosemirror-state';
import { Node as ProsemirrorNode } from 'prosemirror-model';
import StringUtils from '../../../utils/StringUtils';
import SchemaExts, { nodes as MySchemaNodes } from '../schema';
import BlockTitle from '../schema/nodes/BlockTitle';
import { Heading } from '../schema/nodes/Heading';

// 该扩展的作用为:给每个节点添加一个唯一的uuid
export const BlockUUID = Extension.create({
  name: 'ext-block-uuid',
  // 给每个节点添加uuid属性
  addGlobalAttributes() {
    return [
      {
        types: getNodeNames(Doc, BlockTitle, BlockText,Heading),
        attributes: {
          uuid: {
            default: '',
          },
        },
      },
    ];
  },
  // 编辑器创建时,扫描是否缺少uuid或者为空
  onCreate() {
    const tr = this.editor.state.tr;
    const uuidCache: string[] = [];
    let modified = false;
    // doc设置uuid
    if (this.editor.state.doc.attrs.uuid === '') {
      this.editor.state.doc.attrs.uuid = StringUtils.uuidv4();
      modified = true;
    }
    // nodes检测uuid
    this.editor.state.doc.descendants((node, pos) => {
      if (hasUUIDAttr(node)) {
        let uuid = node.attrs.uuid;
        if (uuidCache.includes(uuid) || uuid === '') {
          uuid = StringUtils.uuidv4();
          tr.setNodeMarkup(pos, undefined, { ...node.attrs, uuid });
          modified = true;
        }
        uuidCache.push(uuid);
      }
    });
    if (modified) {
      tr.setMeta('addToHistory', false);
      this.editor.view.dispatch(tr);
    }
  },
  // 每次插入节点时,扫描是否缺少uuid或者为空
  addProseMirrorPlugins() {
    return [
      new Plugin({
        appendTransaction(transactions, oldState, newState) {
          // 如果内容没变化,就忽略检查
          if (oldState.doc.eq(newState.doc)) {
            return;
          }
          // tr
          const newTr = newState.tr;
          // 缓存检查过的uuid
          const uuidCache: string[] = [];
          // 是否有新uuid生成
          let modified = false;
          // 遍历nodes
          newState.doc.descendants((node, pos) => {
            // 判断是否有uuid属性
            if (hasUUIDAttr(node)) {
              // 如果有uuid属性,那么检查
              let uuid = node.attrs.uuid;
              // 如果重复或者是空的
              if (uuidCache.includes(uuid) || uuid === '') {
                // 重新生成uuid
                uuid = StringUtils.uuidv4();
                // 设置到节点上
                newTr.setNodeMarkup(pos, undefined, { ...node.attrs, uuid });
                // 设置标记
                modified = true;
              }
              // 缓存uuid
              uuidCache.push(uuid);
            }
          });
          if (modified) {
            return newTr;
          }
        },
      }),
    ];
  },
});
// 获取节点名称,返回数组
function getNodeNames(...Nodes: Node[]) {
  const nodeNames = Nodes.map((node) => node.name);
  return nodeNames;
}
// 判断节点是否有uuid属性
function hasUUIDAttr(node: ProsemirrorNode) {
  return node.attrs.uuid !== undefined;
}

// renderUUIDAttr
export function uuidAttr(node: ProsemirrorNode) {
  return { 'data-block-id': node.attrs.uuid };
}
export default BlockUUID;
