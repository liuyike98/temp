import "./index.less";
// 题头图和图标
export const HeadImg = (props:any) => {
  return (
    <div className='head-img'>
      <img className='article-head-img' src={props.headImage} />
      <div className='article-head-icon'>
        <img src={props.headIcon} />
      </div>
    </div>
  );
};
