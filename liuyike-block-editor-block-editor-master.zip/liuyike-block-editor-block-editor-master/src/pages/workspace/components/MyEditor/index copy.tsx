import { Editor, EditorContent, BubbleMenu, isTextSelection, Extension } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import React, { CSSProperties, ReactNode } from 'react';
import SchemaExts from './schema';
import FakeData from './data/FakeData';
import MyExtensions from './extension';
import './index.less';
import BlockTitle from './schema/nodes/BlockTitle';
import { Plugin } from 'prosemirror-state';
import { MyToolTip } from './components/MyToolTip';

type propTypes = {
  style?: CSSProperties;
  className?: string;
};

type stateTyps = {
  TipTapEditor: Editor;
};

export default class MyEditor extends React.Component<propTypes, stateTyps> {
  constructor(props: propTypes) {
    super(props);
    this.state = {
      // 初始化编辑器
      TipTapEditor: new Editor({
        extensions: [...SchemaExts, ...MyExtensions],
        content: FakeData,
        editorProps: {
          attributes: {
            // class: 'my-editor',
          },
        },
      }),
    };
    // 挂载编辑器到window上方便调试
    (window as any).editor = this.state.TipTapEditor;
  }
  render(): React.ReactNode {
    return (
      <>
        {/* 选中文字的提示工具栏 */}
        <MyToolTip editor={this.state.TipTapEditor} />
        {/* 编辑器区域 */}
        <EditorContent
          className='my-editor'
          onDragStart={(e) => {
            e.preventDefault();
          }}
          spellCheck={false}
          {...this.props}
          editor={this.state.TipTapEditor}
        />
      </>
    );
  }
}
