import { IconDown } from '@arco-design/web-react/icon';

import React, { ReactNode, ReactPropTypes, useMemo, useRef, useState } from 'react';
import showDragMenu from '../../../../../../components/DragBtnMenu';
import ICON from '../../../../../../components/ICON';
import { Bold } from '../../schema/marks/Bold';
import BlockTitle from '../../schema/nodes/BlockTitle';
import './index.less';
import { Editor, BubbleMenu, Mark } from '@tiptap/react';
import { Popover } from '@arco-design/web-react';
import { Italic } from '../../schema/marks/Italic';
import { Underline } from '../../schema/marks/UnderLine';
import { Strike } from '../../schema/marks/Strike';
import { ShortCode } from '../../schema/marks/ShortCode';
import $ from 'jquery';

type propTypes = { editor: Editor };
type stateTypes = {};
export class MyToolTip extends React.Component<propTypes, stateTypes> {
  constructor(props: propTypes) {
    super(props);
  }
  render(): React.ReactNode {
    return (
      <>
        {this.props.editor && (
          <BubbleMenu
            shouldShow={({ editor, view, state, oldState, from, to }) => {
              const { selection, doc } = state;
              const { empty } = selection;
              const isTitle = selection.content().content.firstChild?.type.name === BlockTitle.name;
              const isEmpty = !selection.content().content;
              const hasFocus = view.hasFocus();
              // 不是标题,选中内容不为空,且有焦点,那么显示
              if (!isTitle && !empty && !isEmpty) {
                return true;
              }
              return false;
            }}
            editor={this.props.editor}
            tippyOptions={{
              delay: [10000, 10000],
              duration: 100,
              zIndex: 0,
              showOnCreate: false,
              onCreate() {
                console.log('onCreate');
              },
            }}>
            <div className='my-tool-tip'>
              {/* 文本格式 */}
              <Btn
                onClick={(e) => {
                  showDragMenu(e.currentTarget);
                }}>
                文本
                <IconDown style={{ marginLeft: 5 }} />
              </Btn>
              <div className='divider' />
              {/* 加粗 */}
              <Btn
                active={this.props.editor.isActive(Bold.name)}
                tip={<span>加粗</span>}
                style={{ fontWeight: 600 }}
                onClick={(e) => {
                  this.props.editor.chain().focus().toggleBold().run();
                }}>
                B
              </Btn>
              {/* 斜体 */}
              <Btn
                active={this.props.editor.isActive(Italic.name)}
                tip={<span>斜体</span>}
                style={{ fontStyle: 'italic' }}
                onClick={() => {
                  this.props.editor.chain().focus().toggleItalic().run();
                }}>
                i
              </Btn>
              {/* 下划线 */}
              <Btn
                active={this.props.editor.isActive(Underline.name)}
                tip={<span>下划线</span>}
                style={{ textDecoration: 'underline' }}
                onClick={() => {
                  this.props.editor.chain().focus().toggleUnderline().run();
                }}>
                U
              </Btn>
              {/* 删除线 */}
              <Btn
                active={this.props.editor.isActive(Strike.name)}
                tip={<span>删除线</span>}
                style={{ textDecoration: 'line-through' }}
                onClick={() => {
                  this.props.editor.chain().focus().toggleStrike().run();
                }}>
                S
              </Btn>
              {/* 短代码 */}
              <Btn
                active={this.props.editor.isActive(ShortCode.name)}
                tip={<span>短代码</span>}
                style={{}}
                onClick={() => {
                  this.props.editor.chain().focus().toggleShortCode().run();
                }}>
                <ICON.CODE className='code' />
              </Btn>
            </div>
          </BubbleMenu>
        )}
      </>
    );
  }
}

function Btn(props: React.HTMLAttributes<HTMLDivElement> & { tip?: ReactNode; active?: boolean }) {
  const [showPopup, setShowPopup] = useState(false);
  const ref = useRef(null);
  return (
    <Popover
      popupVisible={ref && showPopup && props.tip ? true : false}
      popupHoverStay={false}
      unmountOnExit={true}
      color='#0F0F0F'
      position='top'
      content={props.tip}>
      <div
        ref={ref}
        onClick={props.onClick}
        onPointerEnter={() => {
          setShowPopup(true);
        }}
        onPointerLeave={() => {
          setShowPopup(false);
        }}
        style={props.style}
        className={`item ${props.className === undefined ? '' : props.className}`}
        is-active={props.active ? 'true' : undefined}
        onMouseDown={noop}>
        {props.children}
      </div>
    </Popover>
  );
}

function noop(e: any) {
  e.preventDefault();
  e.stopPropagation();
  return false;
}

function windowPointerDown(e: any) {
  // console.log('down');
  pressed = true;
}
function windowPointerUp(e: any) {
  // console.log('up');
  pressed = false;
}


window.removeEventListener('pointerdown', windowPointerDown);
window.removeEventListener('pointerup', windowPointerUp);
window.addEventListener('pointerdown', windowPointerDown);
window.addEventListener('pointerup', windowPointerUp);
let pressed = false;
