import { Editor, FloatingMenu } from '@tiptap/react';
import { EditorState } from 'prosemirror-state';
import { EditorView } from 'prosemirror-view';
import React from 'react';
import './index.less';

type propTypes = {
  editor: Editor;
};
type stateTypes = {};

export default class MyMenuTip extends React.Component<propTypes, stateTypes> {
  constructor(props: propTypes) {
    super(props);
  }

  render(): React.ReactNode {
    return (
      <FloatingMenu
        // shouldShow={({ editor, view, state, oldState }) => {
        //   return false;
        // }}
        editor={this.props.editor}
        tippyOptions={{
          duration: 100,
          interactiveDebounce: 100,
          onShow() {
            console.log('onshow');
            
          },
        }}>
        {this.props.children}
        hello owrld
      </FloatingMenu>
    );
  }
}
