import { Editor, Extension } from '@tiptap/core';
import { Node as ProsemirrorNode } from 'prosemirror-model';
import { Decoration, DecorationSet } from 'prosemirror-view';
import { Plugin, PluginKey } from 'prosemirror-state';
import BlockText from '../schema/nodes/BlockText';

export interface PlaceholderOptions {
  emptyEditorClass: string;
  emptyNodeClass: string;
  placeholder: ((PlaceholderProps: { editor: Editor; node: ProsemirrorNode; pos: number; hasAnchor: boolean }) => string) | string;
  showOnlyWhenEditable: boolean;
  showOnlyCurrent: boolean;
  includeChildren: boolean;
}

export const Placeholder = Extension.create<PlaceholderOptions>({
  addProseMirrorPlugins() {
    return [
      new Plugin({
        key: new PluginKey('ext-placeholder'),
        props: {
          decorations: ({ doc, selection }) => {
            const decorations: Decoration[] = [];
            const { anchor } = selection;
            // 先给标题加
            const titleNode = this.editor.state.doc.nodeAt(0)!;
            if (titleNode.textContent === '') {
              const decoration = Decoration.node(0, 0 + titleNode.nodeSize, {
                placeholder: '未命名文档',
              });
              decorations.push(decoration);
            }
            // 再给正文加
            if (selection.empty && this.editor.isEditable && this.editor.isFocused) {
              let hasFound = false;
              doc.descendants((node: ProsemirrorNode, pos: number) => {
                // 已经找到符合的节点,则不再继续查找
                if (hasFound) {
                  return false;
                }
                const hasAnchor = anchor >= pos && anchor <= pos + node.nodeSize;
                if (hasAnchor && node.type.name === BlockText.name && node.textContent === '') {
                  const decoration = Decoration.node(pos, pos + node.nodeSize, {
                    placeholder: `按下 "/" 输入命令`,
                  });
                  decorations.push(decoration);
                  hasFound = true;
                  this.editor.state.storedMarks = []
                }
                if (node.isTextblock) {
                  return false;
                }
              });
            }
            return DecorationSet.create(doc, decorations);
          },
        },
      }),
    ];
  },
});
