import { Editor, Extension } from '@tiptap/core';
import { Node as ProsemirrorNode } from 'prosemirror-model';
import { Decoration, DecorationSet } from 'prosemirror-view';
import { Plugin, PluginKey } from 'prosemirror-state';
import './index.less';
import $, { extend } from 'jquery';
import React from 'react';
import showDragMenu from '../../../../../../components/DragBtnMenu';

const extName = 'DragPlugin';
let leftBox: HTMLElement | null = null;
let editor: Editor | null = null;
export const DragPlugin = Extension.create({
  name: extName,
  // 插件创建时,添加div
  onCreate(this) {
    editor = this.editor;
    if (leftBox) {
      $(leftBox).remove();
    }
    leftBox = $('<div>').attr('class', extName)[0];
    $('<div>').attr('class', 'add-btn').appendTo(leftBox);
    $('<div>').attr('class', 'drag-btn').appendTo(leftBox);
    $(leftBox).appendTo(editor.view.dom.parentElement!);
    // 添加鼠标移动事件
    editor.view.dom.removeEventListener('mousemove', mousemove as any);
    editor.view.dom.addEventListener('mousemove', mousemove as any);
    hideDragger();
  },
  // 插件销毁时,移除div
  onDestroy() {
    if (leftBox) {
      document.body.removeChild(leftBox);
    }
  },
  // 更新时,隐藏div
  onUpdate() {
    hideDragger();
  },
});

function pointerout() {
  hideDragger();
}

// 鼠标移动事件(仅相应editor的dom)
function mousemove(this: any, e: MouseEvent) {
  // 鼠标当前位置
  const { clientX, clientY } = e;
  // 找到所有可移动的块
  const $blocks = $(this.editor.view.dom).find('div[block-type]');
  // 判断哪个块在命中范围
  for (const block of $blocks) {
    const { top, bottom, left, right } = block.getBoundingClientRect();
    if (clientX > right + 30 || clientX < left - 250) {
      hideDragger();
      break;
    }
    if (clientY >= top && clientY <= bottom) {
      showDragger(block);
      break;
    }
  }
}

// 显示左侧两个图标
function showDragger(block: HTMLElement) {
  if (!leftBox) {
    return;
  }
  const blockRect = block.getBoundingClientRect();
  const editorRect = editor?.view.dom.parentElement?.getBoundingClientRect() || { left: 0, top: 0, right: 0, bottom: 0 };
  $(leftBox)
    .css({
      left: blockRect.left - editorRect.left - (isInList(block) ? 65 : 50),
      top: blockRect.top - editorRect.top + 4,
    })
    .show();
}

// 隐藏左侧两个图标
function hideDragger() {
  if (!leftBox) {
    return;
  }
  $(leftBox).hide();
}

// 判断一个block是否在list中包含
function isInList(blockElement: HTMLElement) {
  if (blockElement.parentElement?.className.includes('list-item')) {
    return true;
  }
  return false;
}
