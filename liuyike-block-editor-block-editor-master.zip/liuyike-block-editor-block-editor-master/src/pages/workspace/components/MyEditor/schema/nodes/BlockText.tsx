import { getSchema, Node } from '@tiptap/react';
import { Fragment, Node as ProsemirrorNode } from 'prosemirror-model';
import { Plugin, Selection, PluginKey } from 'prosemirror-state';
import { Decoration, DecorationSet } from 'prosemirror-view';
import NodeUtils from '../../../../../../utils/NodeUtils';
import { uuidAttr } from '../../extension/BlockUUID';

export const BlockText = Node.create({
  name: 'BlockText',
  group: 'block',
  content: 'inline*',
  defining: true,
  renderHTML({ node, HTMLAttributes }) {
    return ['div', { ...uuidAttr(node), 'block-type': 'text' }, ['div', { class: 'block-content' }, 0]];
  },

  parseHTML() {
    return [
      {
        tag: 'div[block-type="text"]',
      },
      {
        tag:"p"
      }
    ];
  },

  addProseMirrorPlugins() {
    return [
      new Plugin({
        key: new PluginKey('ext-block-text-append-new-line'),
        props: {
          // 在点击空白处时在文章内追加新的 block
          handleClick(view, pos, ev) {
            const lastNode: any = view.dom.lastChild;
            let bottom = 0;
            if (lastNode) {
              bottom = lastNode.offsetTop + lastNode.offsetHeight;
            }
            if (ev.offsetY - bottom > 5) {
              const lastChild = view.state.doc.lastChild;
              // 如果最后一个child不是BlockText,或者是BlockText但是没有内容,则追加新的BlockText
              if (lastChild && (lastChild.type.name !== BlockText.name || lastChild.textContent !== '')) {
                let { tr, schema, doc } = view.state;
                let blankNode = schema.nodes[BlockText.name].create({}, []);
                tr.insert(tr.doc.content.size, blankNode);
                view.dispatch(tr);
                tr = view.state.tr;
                // 不追加到回退栈中
                tr.setSelection(Selection.atEnd(tr.doc)).setMeta('addToHistory', false);
                view.dispatch(tr);
              }
            }
            return false;
          },
        },
      }),
      
    ];
  },
});
export default BlockText;



