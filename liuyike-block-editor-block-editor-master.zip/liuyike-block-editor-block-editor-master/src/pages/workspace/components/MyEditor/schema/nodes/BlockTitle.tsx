import { Node } from '@tiptap/react';
import SchemaExts from '..';
import NodeUtils from '../../../../../../utils/NodeUtils';
import { Placeholder } from '../../extension/Placeholder';
import { uuidAttr } from '../../extension/BlockUUID';
import BlockText from './BlockText';
import { Plugin, PluginKey } from 'prosemirror-state';
import { Decoration, DecorationSet } from 'prosemirror-view';
export const BlockTitle = Node.create({
  name: 'BlockTitle',
  content: 'text*',
  marks: '',
  renderHTML({ node, HTMLAttributes }) {
    return ['div', { class: 'block-title', ...uuidAttr(node) }, 0];
  },
  parseHTML() {
    return [{ tag: 'div.block-title' }];
  },
  addProseMirrorPlugins() {
    return [
      new Plugin({
        key: new PluginKey('ext-block-title-prevent-br-scroll'),
        props: {
          handleScrollToSelection(view) {
            if (view.state.selection.anchor === 1) {
              return true;
            }
            return false;
          },
        },
      }),
    ];
  },
});

export default BlockTitle;
