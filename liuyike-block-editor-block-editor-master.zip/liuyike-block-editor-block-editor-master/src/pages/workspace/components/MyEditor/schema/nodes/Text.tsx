import { Node } from '@tiptap/react';
export const Text = Node.create({
  name: 'text',
  group: 'inline',
 
});

export default Text;
