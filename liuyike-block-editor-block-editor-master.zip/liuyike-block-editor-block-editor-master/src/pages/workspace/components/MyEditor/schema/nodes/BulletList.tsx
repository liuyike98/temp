import { Node, mergeAttributes, wrappingInputRule } from '@tiptap/core';
import { ListItem } from './ListItem';

export interface BulletListOptions {
  HTMLAttributes: Record<string, any>;
}

declare module '@tiptap/core' {
  interface Commands<ReturnType> {
    bulletList: {
      toggleBulletList: () => ReturnType;
    };
  }
}

export const inputRegex = /^\s*([-+*])\s$/;

export const BulletList = Node.create<BulletListOptions>({
  name: 'BulletList',

  addOptions() {
    return {
      HTMLAttributes: {
        class: 'bullet-list',
      },
    };
  },

  group: 'block',

  content() {
    return `${ListItem.name}+`;
  },

  parseHTML() {
    return [
      {
        tag: 'div.bullet-list',
      },
    ];
  },

  renderHTML({ HTMLAttributes }) {
    return ['div', mergeAttributes(this.options.HTMLAttributes, HTMLAttributes), 0];
  },

  addCommands() {
    return {
      toggleBulletList:
        () =>
        ({ commands }) => {
          return commands.toggleList(this.name, ListItem.name);
        },
    };
  },

  addKeyboardShortcuts() {
    return {
      'Mod-Shift-8': () => this.editor.commands.toggleBulletList(),
    };
  },

  addInputRules() {
    return [
      wrappingInputRule({
        find: inputRegex,
        type: this.type,
      }),
    ];
  },
});
