import React, { createRef, PointerEvent, PointerEventHandler, ReactNode, Ref, useRef, useState } from 'react';
import './index.less';
import { uuidv4 } from '../../../../utils/StringUtils';
import { emoji, Triangle } from './icon';

const fakeData: TreeData = [
  {
    title: emoji() + ' 我是第1篇',
    uuid: '1',
    children: [
      {
        title: emoji() + ' 我是第1.1篇',
        uuid: '11',
        children: [
          {
            title: emoji() + ' 我是第1.1.1篇',
            uuid: uuidv4(),
            children: [],
          },
          {
            title: emoji() + ' 我是第1.1.2篇d',
            uuid: uuidv4(),
            children: [],
          },
          {
            title: emoji() + ' 我是第1.1.3篇',
            uuid: uuidv4(),
            children: [],
          },
          {
            title: emoji() + ' 我是第1.1.1篇',
            uuid: uuidv4(),
            children: [],
          },
          {
            title: emoji() + ' 我是第1.1.2篇d',
            uuid: uuidv4(),
            children: [],
          },
          {
            title: emoji() + ' 我是第1.1.3篇',
            uuid: uuidv4(),
            children: [],
          },
          {
            title: emoji() + ' 我是第1.1.1篇',
            uuid: uuidv4(),
            children: [],
          },
          {
            title: emoji() + ' 我是第1.1.2篇d',
            uuid: uuidv4(),
            children: [],
          },
          {
            title: emoji() + ' 我是第1.1.3篇',
            uuid: uuidv4(),
            children: [],
          },
          {
            title: emoji() + ' 我是第1.1.1篇',
            uuid: uuidv4(),
            children: [],
          },
          {
            title: emoji() + ' 我是第1.1.2篇d',
            uuid: uuidv4(),
            children: [],
          },
          {
            title: emoji() + ' 我是第1.1.3篇',
            uuid: uuidv4(),
            children: [],
          },
        ],
      },
    ],
  },
];

type TreeData = TreeItem[];
type TreeItem = {
  title: string | ReactNode;
  uuid: string;
  children?: TreeItem[];
  [key: string]: any;
};
type propTypes = {
  onItemClick?: (item: TreeItem) => void;
  onDragEnd?: (dragUUID: string, dropUUID: string, dropPosition: 'bottom' | 'top' | 'inner') => void;
  onDragStart?: (dragItem: TreeItem) => void;
  onExpand?: (uuid: string) => void;
  treeData?: TreeData;
  expandUUIDS: string[];
  seletedUUID?: string;
};

type stateTypes = {
  treeData: any;
  dropUUID: string;
  dropPosition: '' | 'top' | 'bottom' | 'inner';
  dragStart: boolean;
};

const domMap: Map<string, React.RefObject<HTMLDivElement>> = new Map();

export class MyTree extends React.Component<propTypes, stateTypes> {
  ref = createRef<HTMLDivElement>();
  static defaultProps = {
    expandedKeys: [],
  };
  constructor(props: propTypes) {
    super(props);
    this.state = {
      treeData: fakeData,
      dragStart: false,
      dropUUID: '',
      dropPosition: '',
    };
  }
  shouldComponentUpdate(nextProps: propTypes, nextState: stateTypes) {
    if (this.state.dropUUID !== nextState.dropUUID || this.state.dropPosition !== nextState.dropPosition) {
      return true;
    } else if (this.props !== nextProps) {
      return true;
    }
    return false;
  }
  // 整个树
  render(): React.ReactNode {
    domMap.clear();
    return (
      <div className='comp-my-tree' ref={this.ref}>
        {this.state.treeData.map((item: TreeItem, index: number) => {
          if (item.children && item.children.length > 0) {
            return <this.TreeItemWithChildren indent={0} key={index} data={item} />;
          } else {
            return <this.TreeItem indent={0} key={index} data={item} />;
          }
        })}
      </div>
    );
  }
  // 没有子节点的叶子item
  TreeItem = (props: { [key: string]: any; data: TreeItem }) => {
    if (!domMap.has(props.data.uuid)) {
      domMap.set(props.data.uuid, createRef<HTMLDivElement>());
    }
    return (
      <div
        item-seleted={this.props.seletedUUID === props.data.uuid ? '' : undefined}
        ref={domMap.get(props.data.uuid)}
        onContextMenu={noop as any}
        onPointerDown={(ev) => {
          this.onPointerDown(ev, props.data);
        }}
        className={`tree-item ${props.className ? props.className : ''} ${this.state.dropUUID === props.data.uuid ? 'border-' + this.state.dropPosition : ''}`}>
        <div className='indents'>
          {new Array(props.indent).fill(0).map((_, i) => {
            return <div key={i} className='indent'></div>;
          })}
        </div>
        {props.isParent && (
          <div
            onPointerDown={(e) => {
              e.stopPropagation();
              e.preventDefault();
              this.props.onExpand && this.props.onExpand(props.data.uuid);
            }}
            className='expand-icon'>
            <Triangle />
          </div>
        )}
        <div className='content'>{props.data.title}</div>
      </div>
    );
  };

  // 有子节点的item
  TreeItemWithChildren = (props: { [key: string]: any; data: TreeItem }) => {
    return (
      <div className='tree-item-with-children' data-expanded={this.props.expandUUIDS.includes(props.data.uuid)}>
        <this.TreeItem isParent={true} indent={props.indent} className='parent' data={props.data} />
        {props.data.children?.map((item: TreeItem, index: number) => {
          if (item.children && item.children.length > 0) {
            // 有子节点
            return <this.TreeItemWithChildren indent={props.indent + 1} key={index} data={item} />;
          } else {
            // 无子节点
            return <this.TreeItem indent={props.indent + 1} key={index} data={item} />;
          }
        })}
      </div>
    );
  };

  // 拖拽按下
  onPointerDown = (ev: PointerEvent, item: TreeItem) => {
    if (ev.button === 2) {
      return;
    }
    const dom = this.ref.current;
    const domRect = dom!.getBoundingClientRect();
    const beginX = ev.clientX;
    const beginY = ev.clientY;
    const keepTime = ev.pointerType === 'mouse' ? 0 : 500;
    const dragElement = ev.currentTarget;
    const cloneNode = document.createElement('div');
    // 克隆节点并计算位置
    const dragRect = dragElement.getBoundingClientRect();
    const beginTop = dragRect.top;
    const beginLeft = dragRect.left;
    cloneNode.appendChild(dragElement.cloneNode(true));
    cloneNode.className = 'comp-my-tree-clone';
    cloneNode.style.position = 'absolute';
    cloneNode.style.top = beginTop + 'px';
    cloneNode.style.left = beginLeft + 'px';
    cloneNode.style.width = dragRect.width + 'px';
    cloneNode.style.height = dragRect.height + 'px';
    cloneNode.style.visibility = 'hidden';
    // 设置定时器,长按到一定时间,才可以移动,如果没到时间就移动,那么定时器清空
    const keepTimer = setTimeout(() => {
      // 如果是手机的话,就立刻显示,电脑的话开始拖拽才显示
      if (keepTime) {
        cloneNode.style.visibility = '';
        if (!this.state.dragStart) {
          this.setState({
            dragStart: true,
          });
          // 回调开始事件
          this.props.onDragStart && this.props.onDragStart(item);
        }
      }
      // 长按到时间后禁止滑动操作
      disallowTouch();
      // 添加克隆节点
      document.body.appendChild(cloneNode);
      window.addEventListener('pointermove', onPointerMove);
    }, keepTime);
    // 指针移动事件
    const onPointerMove = (ev: globalThis.PointerEvent) => {
      cloneNode.style.top = beginTop + ev.clientY - beginY + 'px';
      cloneNode.style.left = beginLeft + ev.clientX - beginX + 'px';
      const { clientX, clientY } = ev;
      // 移动幅度过小就不管
      if (Math.abs(clientX - beginX) + Math.abs(clientY - beginY) < 15) {
        return;
      }
      cloneNode.style.visibility = '';
      if (!this.state.dragStart) {
        this.setState({
          dragStart: true,
        });
        // 回调开始事件
        this.props.onDragStart && this.props.onDragStart(item);
      }

      // if(clientX<domRect.left || clientX>domRect.left+domRect.width || clientY>)
      domMap.forEach((ref: React.RefObject<HTMLDivElement>, uuid) => {
        if (!ref || !ref.current) {
          return;
        }
        const rect = ref.current.getBoundingClientRect();
        // 命中检测
        // if (clientY > rect.top && clientY < rect.bottom && clientX > rect.left && clientX < rect.left + rect.width) {
        if (clientY > rect.top && clientY < rect.bottom) {
          if (uuid === Array.from(domMap.keys())[0] && clientY < rect.top + rect.height / 5) {
            this.setState({
              dropUUID: uuid,
              dropPosition: 'top',
            });
          } else if (clientY > rect.top + rect.height / 1.9) {
            this.setState({
              dropUUID: uuid,
              dropPosition: 'bottom',
            });
          } else {
            this.setState({
              dropUUID: uuid,
              dropPosition: 'inner',
            });
          }
        }
      });
    };
    const onPointerUp = () => {
      clearTimeout(keepTimer);
      cloneNode.remove();
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('pointerup', onPointerUp);
      allowTouch();
      // dragstart = false 的时候
      if (!this.state.dragStart) {
        this.props.onItemClick && this.props.onItemClick(item);
        return;
      }
      // 已经拖动过的时候
      if (this.state.dropPosition) {
        this.props.onDragEnd && this.props.onDragEnd(item.uuid, this.state.dropUUID, this.state.dropPosition);
      }
      this.setState({
        dragStart: false,
        dropPosition: '',
        dropUUID: '',
      });
    };
    // 抬起手势时候,恢复允许滑动
    window.addEventListener('pointerup', onPointerUp);
    // 只要移动一次,就清掉timer
    window.addEventListener(
      'pointermove',
      () => {
        clearTimeout(keepTimer);
      },
      { once: true }
    );
    // 允许滑动
    function allowTouch() {
      window.removeEventListener('touchmove', noop);
    }
    // 禁止滑动
    function disallowTouch() {
      window.addEventListener('touchmove', noop, { passive: false });
    }
  };
}

function noop(e: globalThis.TouchEvent) {
  try {
    if (e.cancelable) {
      e.preventDefault();
      e.stopPropagation();
      return false;
    }
  } catch (_) {}
}
