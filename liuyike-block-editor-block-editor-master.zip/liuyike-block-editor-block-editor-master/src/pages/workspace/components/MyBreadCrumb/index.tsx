import { Breadcrumb } from "@arco-design/web-react";
import ICON from "../../../../components/ICON";
import "./index.less";
// 面包屑导航
export const MyBreadCrumb = (props: any) => {
  return (
    <div className='my-breadcrumb'>
      <Breadcrumb>
        <Breadcrumb.Item className='breadcrumb-item'>
          <a>自由创作</a>
        </Breadcrumb.Item>
        <Breadcrumb.Item className='breadcrumb-item'>
          <a>功能介绍</a>
        </Breadcrumb.Item>
        <Breadcrumb.Item className='breadcrumb-item'>
          <a>开源相关</a>
        </Breadcrumb.Item>
      </Breadcrumb>
      <ICON.COLLECT className='collect' />
      <ICON.MORE className='more-menu' />
    </div>
  );
};