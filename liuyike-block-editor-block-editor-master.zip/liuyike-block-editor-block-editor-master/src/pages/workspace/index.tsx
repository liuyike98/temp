import { Breadcrumb, Icon, Message, Popconfirm, ResizeBox } from '@arco-design/web-react';
import React, { useState } from 'react';

import * as ICON from '../../components/ICON';
import './index.less';
import src_article_head from '../../assets/pics/head.png';
import src_article_icon from '../../assets/pics/title-icon.svg';
import { MyBreadCrumb } from './components/MyBreadCrumb';
import { HeadImg } from './components/HeadImg';
import MyEditor from './components/MyEditor';
import { MyTree } from './components/MyTree';

type WorkspacePropTypes = {};

type WorkspaceStateTypes = {
  noteData: {
    headImage: string;
    headIcon: string;
    title: string;
  };
};
export default class Workspace extends React.Component<WorkspacePropTypes, WorkspaceStateTypes> {
  constructor(props: any) {
    super(props);
    this.state = {
      noteData: {
        headImage: src_article_head,
        headIcon: src_article_icon,
        title: '你好世界',
      },
    };
  }

  // 左侧的树形菜单
  LeftMenu = (props: any) => {
    const [selected, setSelected] = useState('1');
    const [expanded, setExpanded] = useState([] as string[]);
    return (
      <div className='left-menu'>
        工作空间占位符
        <MyTree
          seletedUUID={selected}
          expandUUIDS={expanded}
          onItemClick={(item) => {
            console.log(item);
            setSelected(item.uuid);
          }}
          onDragStart={(item) => {
            console.log('begin', item);
          }}
          onDragEnd={(dragUUID, dropUUID, dropPosition) => {
            console.log('end', dragUUID, dropUUID, dropPosition);
          }}
          onExpand={(uuid) => {
            console.log('expand', uuid);
            if (expanded.includes(uuid)) {
              expanded.splice(expanded.indexOf(uuid), 1);
              setExpanded(JSON.parse(JSON.stringify(expanded)));
            } else {
              expanded.push(uuid);
              setExpanded(JSON.parse(JSON.stringify(expanded)));
            }
          }}
        />
      </div>
    );
  };

  // 主体内容
  MainContent = (props: any) => {
    return (
      <div className='main-content'>
        {/* 面包屑 */}
        <MyBreadCrumb />
        <div className='article-area'>
          {/* 题头图和图标 */}
          <HeadImg headImage={this.state.noteData.headImage} headIcon={this.state.noteData.headIcon} />
          <div className='editor-container'>
            {/* Editor组件 */}
            <MyEditor />
          </div>
        </div>
      </div>
    );
  };

  // 渲染页面
  render(): React.ReactNode {
    return (
      <div className='page-workspace'>
        <ResizeBox.Split
          trigger={
            <div
              onMouseDown={() => {
                document.body.style.userSelect = 'none';
              }}
              onMouseUp={() => {
                document.body.style.userSelect = 'auto';
              }}
              className='spliter'
            />
          }
          size={'260px'}
          min={0}
          max={400}
          disabled={false}
          style={{ height: '100%', width: '100%' }}
          // 左右分栏
          panes={[<this.LeftMenu />, <this.MainContent />]}
        />
      </div>
    );
  }
}
