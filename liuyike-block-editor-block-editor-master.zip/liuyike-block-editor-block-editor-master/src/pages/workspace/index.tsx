import {
  Breadcrumb,
  Icon,
  Message,
  Popconfirm,
  ResizeBox,
} from "@arco-design/web-react";
import React from "react";

import * as ICON from "../../components/ICON";
import "./index.less";
import src_article_head from "../../assets/pics/head.png";
import src_article_icon from "../../assets/pics/title-icon.svg";
import { MyBreadCrumb } from "./components/MyBreadCrumb";
import { HeadImg } from "./components/HeadImg";
import MyEditor from "../../components/MyEditor";

type WorkspacePropTypes = {};

type WorkspaceStateTypes = {
  noteData: {
    headImage: string;
    headIcon: string;
    title: string;
  };
};
export default class Workspace extends React.Component<
  WorkspacePropTypes,
  WorkspaceStateTypes
> {
  constructor(props: any) {
    super(props);
    this.state = {
      noteData: {
        headImage: src_article_head,
        headIcon: src_article_icon,
        title: "你好世界",
      },
    };
  }

  // 左侧的树形菜单
  LeftMenu = (props: any) => {
    return <div className="left-menu"></div>;
  };

  // 主体内容
  MainContent = (props: any) => {
    return (
      <div className="main-content">
        {/* 面包屑 */}
        <MyBreadCrumb />
        <div className="article-area">
          {/* 题头图和图标 */}
          <HeadImg
            headImage={this.state.noteData.headImage}
            headIcon={this.state.noteData.headIcon}
          />
          <div className="editor-container">
            {/* Editor组件 */}
            <MyEditor />
          </div>
        </div>
      </div>
    );
  };

  // 渲染页面
  render(): React.ReactNode {
    return (
      <div className="page-workspace">
        <ResizeBox.Split
          trigger={
            <div
              onMouseDown={() => {
                document.body.style.userSelect = "none";
              }}
              onMouseUp={() => {
                document.body.style.userSelect = "auto";
              }}
              className="spliter"
            />
          }
          size={"26px"}
          min={0}
          max={400}
          disabled={false}
          style={{ height: "100%", width: "100%" }}
          // 左右分栏
          panes={[<this.LeftMenu />, <this.MainContent />]}
        />
      </div>
    );
  }
}
