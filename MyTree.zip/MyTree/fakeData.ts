export const TreeData = [
    {
        uuid: '1', 
        title: '我是程玲1', 
        before: '', 
        after: '2', 
        parentUUID: '',
        children: [
            {
                uuid: '11',
                title: '我是程玲11', 
                before: '', 
                after: '12', 
                parentUUID: '1',
                children: [
                    {
                        uuid: '111', 
                        title: '我是程玲111', 
                        before: '', 
                        after: '112', 
                        parentUUID: '11',
                    },
                    {
                        uuid: '112', 
                        title: '我是程玲112', 
                        before: '111', 
                        after: '', 
                        parentUUID: '11',
                    },
                ]
            }
        ]
    },
    {
        uuid: '2', 
        title: '我是程玲2', 
        before: '1', 
        after: '3', 
        parentUUID: '',
        children: [
            {
                uuid: '21',
                title: '我是程玲21', 
                before: '',
                after: '', 
                parentUUID: '2',
                children: [
                    {
                        uuid: '211', 
                        title: '我是程玲211', 
                        before: '', 
                        after: '', 
                        parentUUID: '21',
                    },
                ]
            }
        ]
    },
    {
        uuid: '3', 
        title: '我是程玲3', 
        before: '2', 
        after: '4', 
        parentUUID: '',
        children: [
            {
                uuid: '31',
                title: '我是程玲31', 
                before: '',
                after: '32', 
                parentUUID: '3',
                children: [
                    {
                        uuid: '311', 
                        title: '我是程玲311', 
                        before: '', 
                        after: '', 
                        parentUUID: '31',
                    },
                ]
            },
            {
                uuid: '32',
                title: '我是程玲32', 
                before: '',
                after: '', 
                parentUUID: '3',
            }
        ]
    },
    {
        uuid: '4', 
        title: '我是程玲4', 
        before: '3', 
        after: '', 
        parentUUID: '',
        // children: [
        //     {
        //         uuid: '41',
        //         title: '我是程玲41', 
        //         before: '',
        //         after: '42', 
        //         parentUUID: '4',
        //     },
        //     {
        //         uuid: '42',
        //         title: '我是程玲42', 
        //         before: '41',
        //         after: '43', 
        //         parentUUID: '4',
        //     },
        //     {
        //         uuid: '43',
        //         title: '我是程玲43', 
        //         before: '42',
        //         after: '', 
        //         parentUUID: '4',
        //     }
        // ]
    }
]

