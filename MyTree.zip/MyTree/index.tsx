import React, { Component } from 'react';
import { Row, Col, Tree } from 'antd';
import { TreeData } from './fakeData';
import './index.less';

export type TreeNodeType = {
    uuid: string;
    title: string;
    before: string;
    after: string;
    parentUUID?: string;
    children?: TreeNodeType[];
}
type propTypes = {};
type stateTypes = {
    expandedKeys: [];
    treeData: TreeNodeType[];
};

export default class MyTree extends Component<propTypes, stateTypes> {
    constructor(props: propTypes) {
        super(props);
        this.state = {
            expandedKeys: [],
            treeData: []
        }
    }

    componentDidMount() {
        this.setState({
            treeData: TreeData
        })
    }

    onDrop = (info: any) => {
        const dropKey = info.node.uuid;
        const dragKey = info.dragNode.uuid;
        const dropPos = info.node.pos.split('-');
        const dropPosition = info.dropPosition - Number(dropPos[dropPos.length - 1]);
        const data = [...this.state.treeData];
        // Find dragObject
        let dragObj = {};
        let moveObj: any = [];

        const loop = (data: any, uuid: string, callback: any) => {
            for (let i = 0; i < data.length; i++) {
                if (data[i].uuid === uuid) {
                    return callback(data[i], i, data);
                }
                if (data[i].children) {
                    loop(data[i].children, uuid, callback);
                }
            }
        };

        const moveBefore = (info: any, data: TreeNodeType[], index: number) => {
            // 判断同一级的数据须大于1，不然移动前不做处理
            if (data.length > 1) {
                if (index === 0) {
                    const nextNode = data[index + 1];
                    nextNode.before = '';
                    moveObj.push(nextNode);
                } else if (index == data.length - 1) {
                    const preNode = data[data.length - 2];
                    preNode.after = '';
                    moveObj.push(preNode);
                } else {
                    const preNode = data[index - 1];
                    const nextNode = data[index + 1];
                    preNode.after = nextNode.uuid;
                    nextNode.before = preNode.uuid;
                    moveObj.push(preNode);
                    moveObj.push(nextNode);
                }
            }

        }

        const moveAfter = (info: any, data: TreeNodeType[], index: number) => {
            const { dragNode, node } = info;
            const tempData = JSON.parse(JSON.stringify(data));
            // 子级移动到父级层，需要改变parentUUID
            if (dragNode.pos.split('-').length > node.pos.split('-').length) {
                dragNode.parentUUID = node.parentUUID;
            }
            if (index === 0 && node.dragOverGapTop) {
                dragNode.before = '';
                dragNode.after = node.uuid;
                node.before = dragNode.uuid;

                moveObj.push(dragNode);
                moveObj.push(node);
            } else if (index === tempData.length - 1 && info.dropToGap) {
                dragNode.before = node.uuid;
                dragNode.after = '';
                node.after = dragNode.uuid;
                moveObj.push(dragNode);
                moveObj.push(node);
            } else if (node.dragOverGapBottom) {
                const nextDropNode = tempData[index + 1];
                dragNode.before = node.uuid;
                dragNode.after = nextDropNode.uuid;
                node.after = dragNode.uuid;
                nextDropNode.before = dragNode.uuid;
                moveObj.push(dragNode);
                moveObj.push(node);
                moveObj.push(nextDropNode);
            } else if (index !== 0 && node.dragOverGapTop) {
                const preDropNode = tempData[index - 1];
                dragNode.before = preDropNode.uuid;
                dragNode.after = node.uuid;
                node.before = dragNode.uuid;
                preDropNode.after = dragNode.uuid;
                moveObj.push(dragNode);
                moveObj.push(node);
                moveObj.push(preDropNode);
            } else {
                dragNode.parentUUID = node.uuid;
                dragNode.before = '';
                if (node.children && node.children.length > 0) {
                    const innerFirst = node.children[0];
                    dragNode.after = innerFirst.uuid;
                    innerFirst.before = dragNode.uuid;
                    moveObj.push(dragNode);
                    moveObj.push(innerFirst);
                } else {
                    dragNode.after = '';
                    moveObj.push(dragNode);
                }

            }

        }

        loop(data, dragKey, (item: TreeNodeType, index: number, arr: TreeNodeType[]) => {
            moveBefore(info, arr, index);
            arr.splice(index, 1);
            dragObj = item;
        });

        if (!info.dropToGap) {
            // Drop on the content
            loop(data, dropKey, (item: any, index: number, arr: any) => {
                moveAfter(info, arr, index);
                item.children = item.children || [];
                // where to insert 示例添加到头部，可以是随意位置
                item.children.unshift(dragObj);
            });
        }
        //  else if (
        //     (info.node.props.children || []).length > 0 && // Has children
        //     info.node.props.expanded && // Is expanded
        //     dropPosition === 1 // On the bottom gap
        // ) {
        //     loop(data, dropKey, (item: any) => {
        //         item.children = item.children || [];
        //         // where to insert 示例添加到头部，可以是随意位置
        //         item.children.unshift(dragObj);
        //         // in previous version, we use item.children.push(dragObj) to insert the
        //         // item to the tail of the children
        //     });
        // } 
        else {
            let ar: any = [];
            let i: number = 0;
            loop(data, dropKey, (item: TreeNodeType, index: number, arr: TreeNodeType[]) => {
                ar = arr;
                i = index;
            });
            if (dropPosition === -1) {
                moveAfter(info, ar, i);
                ar.splice(i, 0, dragObj);
            } else {
                moveAfter(info, ar, i);
                ar.splice(i + 1, 0, dragObj);
            }
        }
        console.log(moveObj, 111);
        this.setState({
            treeData: data,
        });
    }

    render() {
        return (
            <Tree
                className="draggable-tree"
                expandedKeys={this.state.expandedKeys}
                fieldNames={{ key: 'uuid' }}
                draggable={{ icon: false }}
                blockNode
                onDrop={this.onDrop}
                onExpand={(expandedKeys: []) => {
                    this.setState({
                        expandedKeys
                    })
                }}
                treeData={this.state.treeData}
            />
        )
    }
}