import { Activity } from '../../runtime/Activity';

export class MainActivity extends Activity {
  protected onCreate(): void {
    this.setContentLayout({ filePath: '', devUrl: `http://${process.env['VITE_DEV_SERVER_HOST']}:${process.env['VITE_DEV_SERVER_PORT']}` });
  }
  protected onDestroy(ev: Electron.Event): void {
    console.log('ondestroy');
  }
}
