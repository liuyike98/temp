import { FragmentView } from '../../../runtime/FragmentView';

export class TestFragment extends FragmentView {
  protected onMounted(): void {}
}
