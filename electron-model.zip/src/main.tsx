import ReactDOM from 'react-dom';
import { TestFragment } from './fragments/TestFragment';

ReactDOM.render(
  <>
    <TestFragment />
  </>,
  document.getElementById('root')!
);

postMessage({ payload: 'removeLoading' }, '*');
