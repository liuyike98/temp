import { Activity } from '../Activity';

export class Intent {
 
}
