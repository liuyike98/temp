import { Activity } from '../Activity';

export const Logger = {
  log,
  info,
  warn,
  error,
  debug,
};

function log(...message: any) {
  console.log(...message);
  return Logger;
}

function info(...message: any) {
  console.info(...message);
  return Logger;
}

function warn(...message: any) {
  console.warn(...message);
  return Logger;
}

function error(...message: any) {
  console.error(...message);
  return Logger;
}

function debug(...message: any) {
  console.debug(...message);
  return Logger;
}
