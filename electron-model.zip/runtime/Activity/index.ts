import { app, BrowserWindow, BrowserWindowConstructorOptions } from 'electron';
import { Intent } from '../Intent';
import { LayoutConfig } from '../Types/Layout';

export abstract class Activity extends BrowserWindow {
  // the tag is named with the instance name by default.
  TAG: string = `[${this.constructor.name}]`;

  constructor(config?: { intent?: Intent; options?: BrowserWindowConstructorOptions }) {
    const defaultOptions: BrowserWindowConstructorOptions = {
      webPreferences: {
        webviewTag: true,
      },
    };
    super({ ...defaultOptions, ...config?.options });
    this.onCreate();
    this.on('close', this.onDestroy);
    this.on('hide', this.onHide);
    this.on('minimize', this.onMinimize);
    this.on('maximize', this.onMaxmize);
    this.on('restore', this.onRestore);
    this.on('unmaximize', this.onUnMaxmize);
    this.on('blur', this.onBlur);
    this.on('focus', this.onFocus);
  }
  // android lifecycle
  protected abstract onCreate(): void;
  protected abstract onDestroy(ev: Electron.Event): void;
  // [position/location] change event
  protected onShow(): void {}
  protected onHide(): void {}
  protected onMinimize(): void {}
  protected onMaxmize(): void {}
  protected onUnMaxmize(): void {}
  protected onRestore(): void {}
  // focus change event
  protected onBlur() {}
  protected onFocus() {}
  // receive new intent
  protected onNewIntent(intent: Intent): void {}

  // methods
  private getContext() {
    return this;
  }

  protected setContentLayout(layout: LayoutConfig) {
    if (app.isPackaged) {
      this.loadFile(layout.filePath);
    } else {
      this.loadURL(layout.devUrl);
    }
  }

  protected broadcastIntent(intent: Intent) {}

  protected startActivity(intent?: Intent) {}
}
