import React from 'react';
import { ViewConfig } from '../Types/Layout';

export abstract class FragmentView extends React.Component {

  protected constructor(props: any) {
    super(props);
  }
  render(): React.ReactNode {
    
    return <webview src={'https://baidu.com'}></webview>;
  }

  // lifecycle define
  protected abstract onMounted(): void;
}
