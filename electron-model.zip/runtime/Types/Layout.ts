export type LayoutConfig = {
  devUrl: string;
  filePath: string;
};
export type ViewConfig = {
  devUrl: string;
  filePath: string;
};
